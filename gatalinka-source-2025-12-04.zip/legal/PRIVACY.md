﻿# Politika privatnosti (skica)

- Podaci: ime (iz Google prijave), datum rođenja i spol (opcionalno), fotografije šalica.
- Svrha: generiranje personaliziranog, zabavnog tumačenja.
- Pravna osnova: privola.
- Prava korisnika: pristup, ispravak, brisanje, prenosivost, povlačenje privole.
- Retencija: minimalna; slike se brišu nakon obrade (osim uz eksplicitnu privolu za poboljšanje modela).

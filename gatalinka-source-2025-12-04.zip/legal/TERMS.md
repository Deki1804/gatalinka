﻿# Uvjeti korištenja (skica)

Korištenjem aplikacije prihvaćate da su rezultati **zabavnog karaktera** i da Gatalinka ne preuzima odgovornost za odluke donesene na temelju prikazanog sadržaja.

﻿# Gatalinka API (skica)

Stack: FastAPI (Python).
Planirani endpointi:
- POST /analyze-cup (image) -> detekcija uzoraka/regiona
- POST /generate-reading (dob, spol, horoscope?, features) -> tekst
- GET  /health

Autentikacija: Firebase token (idToken) ili API key (admin).

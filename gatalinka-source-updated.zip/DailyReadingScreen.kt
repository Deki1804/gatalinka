package com.gatalinka.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import kotlinx.coroutines.launch
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gatalinka.app.api.FirebaseFunctionsService
import com.gatalinka.app.data.UserPreferencesRepository
import com.gatalinka.app.ui.model.GatalinkaReadingUiModel
import com.gatalinka.app.vm.ReadingViewModel
import kotlinx.coroutines.flow.first

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DailyReadingScreen(
    preferencesRepo: UserPreferencesRepository,
    onBack: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var isLoading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<GatalinkaReadingUiModel?>(null) }
    
    // Učitaj dnevno čitanje
    LaunchedEffect(Unit) {
        isLoading = true
        error = null
        try {
            val userInput = preferencesRepo.userInput.first()
            val response = FirebaseFunctionsService.getDailyReading(userInput)
            
            val uiModel = GatalinkaReadingUiModel(
                mainText = response.mainText,
                love = response.love,
                work = response.work,
                money = response.money,
                health = response.health,
                symbols = response.symbols,
                luckyNumbers = response.luckyNumbers,
                luckScore = response.luckScore,
                mantra = response.mantra,
                energyScore = response.energyScore
            )
            
            result = uiModel
        } catch (e: Exception) {
            error = when {
                e.message?.contains("prijavljen", ignoreCase = true) == true ->
                    "Niste prijavljeni. Molimo prijavite se."
                e.message?.contains("network", ignoreCase = true) == true ->
                    "Ne mogu se spojiti na server. Provjeri internetsku vezu."
                else ->
                    "Greška: ${e.message ?: e.javaClass.simpleName}"
            }
        } finally {
            isLoading = false
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF1A0B2E), // Mystic Purple Deep
                        Color(0xFF2D1B4E)  // Mystic Purple Medium
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Top Bar
            TopAppBar(
                title = {
                    Text(
                        "Dnevno čitanje",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color(0xFFFFD700)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            "Nazad",
                            tint = Color(0xFFEFE3D1)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )

            // Content
            when {
                isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator(color = Color(0xFFFFD700))
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                "Učitavam dnevno čitanje...",
                                color = Color(0xFFEFE3D1),
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                    }
                }
                error != null -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                error ?: "Greška",
                                color = Color(0xFFFF6B6B),
                                style = MaterialTheme.typography.titleMedium,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        isLoading = true
                                        error = null
                                        try {
                                            val userInput = preferencesRepo.userInput.first()
                                            val response = FirebaseFunctionsService.getDailyReading(userInput)
                                            
                                            val uiModel = GatalinkaReadingUiModel(
                                                mainText = response.mainText,
                                                love = response.love,
                                                work = response.work,
                                                money = response.money,
                                                health = response.health,
                                                symbols = response.symbols,
                                                luckyNumbers = response.luckyNumbers,
                                                luckScore = response.luckScore,
                                                mantra = response.mantra,
                                                energyScore = response.energyScore
                                            )
                                            
                                            result = uiModel
                                        } catch (e: Exception) {
                                            error = "Greška: ${e.message ?: e.javaClass.simpleName}"
                                        } finally {
                                            isLoading = false
                                        }
                                    }
                                }
                            ) {
                                Text("Pokušaj ponovo")
                            }
                        }
                    }
                }
                result != null -> {
                    // Koristi isti ReadingResultScreen za prikaz
                    ReadingResultScreen(
                        result = result!!,
                        imageUri = "", // Nema slike za dnevno čitanje
                        onBack = onBack,
                        onSave = { /* Daily reading se automatski sprema u backend */ }
                    )
                }
            }
        }
    }
}


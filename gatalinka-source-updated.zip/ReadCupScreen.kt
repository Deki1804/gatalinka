package com.gatalinka.app.ui.screens

import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gatalinka.app.R
import com.gatalinka.app.api.FirebaseFunctionsService
import com.gatalinka.app.api.dto.GatalinkaReadingDto
import com.gatalinka.app.data.UserPreferencesRepository
import com.gatalinka.app.ui.components.ReadingGlowEffect
import com.gatalinka.app.ui.components.MysticOrb
import com.gatalinka.app.ui.design.BeanCTA
import com.gatalinka.app.ui.design.GataUI
import com.gatalinka.app.ui.model.GatalinkaReadingUiModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@Composable
fun ReadCupScreen(
    imageUri: String,
    readingMode: String = "instant",
    preferencesRepo: UserPreferencesRepository,
    onBack: () -> Unit,
    onViewResult: (GatalinkaReadingUiModel) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<GatalinkaReadingUiModel?>(null) }
    
    // Pokreni čitanje jednom
    LaunchedEffect(imageUri) {
        isLoading = true
        errorMessage = null
        result = null
        
        try {
            val cleanImageUri = imageUri.split("?")[0]
            val uri = Uri.parse(cleanImageUri)
            val userInput = preferencesRepo.userInput.first()
            
            val response = FirebaseFunctionsService.readCup(
                imageUri = uri,
                context = context,
                userInput = userInput,
                readingMode = readingMode
            )
            
            if (!response.isValidCup) {
                errorMessage = when (response.reason) {
                    "image_too_small", "image_too_small_dimensions" ->
                        "📸 Fotografija je premala\n\nPribliži šalicu i slikaj u boljem svjetlu. Šalica treba biti jasno vidljiva i oštra."
                    "bad_aspect_ratio" ->
                        "📐 Pogrešan kut\n\nFotkaj šalicu odozgo, direktno. Šalica treba biti u centru okvira, kao krug."
                    "too_dark" ->
                        "🌙 Previše tamno\n\nUključi svjetlo ili priđi bliže prozoru. Talog mora biti dovoljno vidljiv."
                    "too_bright" ->
                        "☀️ Previše svijetlo\n\nPokušaj bez blica ili malo dalje od svjetla. Trebamo vidjeti detalje taloga."
                    "low_contrast" ->
                        "🔍 Mutna slika\n\nDrži mobitel mirnije i približi se. Trebamo jasno vidjeti oblike u talogu."
                    "analysis_failed" ->
                        "⚠️ Greška pri analizi\n\nPokušaj ponovno ili odaberi drugu fotografiju. Provjeri da je šalica jasno vidljiva."
                    else ->
                        "❓ Nešto nije u redu\n\nPokušaj ponovno uz jasnu sliku šalice odozgo, u dobrom svjetlu."
                }
                isLoading = false
                return@LaunchedEffect
            }
            
            if (response.safetyLevel == "nsfw" || response.reason == "nsfw_detected") {
                errorMessage = "🚫 Fotografija nije prikladna\n\nMolimo koristi fotografiju šalice kave za čitanje."
                isLoading = false
                return@LaunchedEffect
            }
            
            // Mapiraj u UI model
            val uiModel = GatalinkaReadingUiModel(
                mainText = response.mainText,
                love = response.love,
                work = response.work,
                money = response.money,
                health = response.health,
                symbols = response.symbols,
                luckyNumbers = response.luckyNumbers,
                luckScore = response.luckScore,
                mantra = response.mantra,
                energyScore = response.energyScore
            )
            
            result = uiModel
            isLoading = false
            
            android.util.Log.d("ReadCupScreen", "✅ Rezultat primljen! luckScore=${uiModel.luckScore}, mainText length=${uiModel.mainText.length}")
            android.util.Log.d("ReadCupScreen", "Pozivanje onViewResult...")
            
            // Navigiraj direktno
            onViewResult(uiModel)
            
            android.util.Log.d("ReadCupScreen", "onViewResult pozvan - navigacija bi trebala biti u tijeku")
            
        } catch (e: Exception) {
            errorMessage = when {
                e.message?.contains("prijavljen", ignoreCase = true) == true ||
                e.message?.contains("authenticated", ignoreCase = true) == true ||
                e.message?.contains("UNAUTHENTICATED", ignoreCase = true) == true ->
                    "🔐 Niste prijavljeni\n\nMolimo prijavite se i pokušajte ponovo."
                e.message?.contains("timeout", ignoreCase = true) == true ->
                    "⏱️ Vrijeme je isteklo\n\nAI analiza traje predugo. Pokušaj ponovo."
                e.message?.contains("network", ignoreCase = true) == true ->
                    "📡 Nema internetske veze\n\nProvjeri svoju internetsku vezu i pokušaj ponovo."
                else ->
                    "❌ Greška\n\n${e.message ?: "Nešto je pošlo po zlu. Pokušaj ponovo."}"
            }
            isLoading = false
        }
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1E1510))
    ) {
        // Pozadina
        Image(
            painter = painterResource(id = R.drawable.coffee_cup_bg_ext),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            alignment = Alignment.TopCenter,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    translationY = (-100).dp.toPx()
                    scaleX = 1.10f
                    scaleY = 1.10f
                }
        )

        // Scrim
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(280.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color(0x33000000),
                            Color(0x55000000)
                        )
                    )
                )
        )
        
        // Mystic effects dok se čita - WOW verzija
        if (isLoading) {
            // Enhanced ReadingGlowEffect
            ReadingGlowEffect(
                modifier = Modifier.fillMaxSize(),
                centerX = null,
                centerY = null,
                color = Color(0xFFFFD700).copy(alpha = 0.5f)
            )
            
            // Multiple floating orbs
            MysticOrb(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFFFFD700).copy(alpha = 0.3f),
                size = 100f
            )
            
            // Particles overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(0.6f)
            ) {
                com.gatalinka.app.ui.components.Sparkles(particleCount = 60)
            }
            
            // Mist overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color(0xFF2D1B4E).copy(alpha = 0.3f),
                                Color(0xFF1A0B2E).copy(alpha = 0.5f)
                            )
                        )
                    )
            )
        }

        // Sadržaj
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = GataUI.ScreenPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Bottom
        ) {
            AnimatedVisibility(
                visible = isLoading,
                enter = fadeIn() + slideInVertically(initialOffsetY = { 20 }),
                exit = fadeOut() + slideOutVertically(targetOffsetY = { -20 })
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Animated text
                    val infiniteTransition = rememberInfiniteTransition(label = "loading_pulse")
                    val textAlpha by infiniteTransition.animateFloat(
                        initialValue = 0.6f,
                        targetValue = 1f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(1000, easing = FastOutSlowInEasing),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "text_alpha"
                    )
                    
                    Text(
                        text = "U tijeku je ritual čitanja…",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            color = Color(0xFFFFE9C6),
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp
                        ),
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                            .alpha(textAlpha)
                    )
                    
                    Text(
                        text = "Tvoja šalica otkriva sudbinu",
                        style = MaterialTheme.typography.bodyLarge.copy(
                            color = Color(0xFFFFE9C6).copy(alpha = 0.8f),
                            fontSize = 16.sp
                        ),
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 18.dp)
                            .alpha(textAlpha * 0.8f)
                    )
                    
                    CircularProgressIndicator(
                        modifier = Modifier.padding(16.dp),
                        color = Color(0xFFFFE9C6)
                    )
                }
            }
            
            AnimatedVisibility(
                visible = errorMessage != null,
                enter = fadeIn() + slideInVertically(initialOffsetY = { 20 }),
                exit = fadeOut() + slideOutVertically(targetOffsetY = { -20 })
            ) {
                if (errorMessage != null) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = errorMessage ?: "Greška",
                            style = MaterialTheme.typography.headlineSmall.copy(
                                color = Color(0xFFFFE9C6),
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp
                            ),
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 18.dp)
                        )
                        
                        BeanCTA(
                            label = "Pokušaj ponovo",
                            onClick = {
                                scope.launch {
                                    isLoading = true
                                    errorMessage = null
                                    result = null
                                    
                                    try {
                                        val cleanImageUri = imageUri.split("?")[0]
                                        val uri = Uri.parse(cleanImageUri)
                                        val userInput = preferencesRepo.userInput.first()
                                        
                                        val response = FirebaseFunctionsService.readCup(
                                            imageUri = uri,
                                            context = context,
                                            userInput = userInput,
                                            readingMode = readingMode
                                        )
                                        
                                        if (!response.isValidCup || response.safetyLevel == "nsfw") {
                                            errorMessage = "Fotografija nije prikladna za čitanje."
                                            isLoading = false
                                            return@launch
                                        }
                                        
                                        val uiModel = GatalinkaReadingUiModel(
                                            mainText = response.mainText,
                                            love = response.love,
                                            work = response.work,
                                            money = response.money,
                                            health = response.health,
                                            symbols = response.symbols,
                                            luckyNumbers = response.luckyNumbers,
                                            luckScore = response.luckScore,
                                            mantra = response.mantra,
                                            energyScore = response.energyScore
                                        )
                                        
                                        result = uiModel
                                        isLoading = false
                                        onViewResult(uiModel)
                                        
                                    } catch (e: Exception) {
                                        errorMessage = "Nešto je pošlo po zlu: ${e.message ?: e.javaClass.simpleName}"
                                        isLoading = false
                                    }
                                }
                            }
                        )
                        
                        Spacer(Modifier.height(8.dp))
                        
                        BeanCTA(
                            label = "Nazad",
                            onClick = onBack
                        )
                    }
                }
            }
            
            AnimatedVisibility(
                visible = result != null,
                enter = fadeIn() + slideInVertically(initialOffsetY = { 20 }),
                exit = fadeOut()
            ) {
                if (result != null) {
                    // Ovo se ne bi trebalo prikazati jer navigacija treba biti trenutna
                    CircularProgressIndicator(
                        modifier = Modifier.padding(16.dp),
                        color = Color(0xFFFFE9C6)
                    )
                    Text(
                        text = "Čitanje je gotovo!",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            color = Color(0xFFFFE9C6),
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp
                        ),
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 18.dp)
                    )
                }
            }

            Spacer(Modifier.height(40.dp))
        }
    }
}

package com.gatalinka.app.ui.design

import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.*
import com.gatalinka.app.ui.components.CoffeeBeanImageButton

object GataUI {
    // Boje
    val Beige = Color(0xFFFFE9C6)

    // Dimenzije - WOW verzija s konzistentnim spacing-om
    val ScreenPadding = 24.dp
    val CardPadding = 20.dp
    val CardSpacing = 16.dp
    val SectionSpacing = 24.dp
    val BeanWidth = 260.dp
    val BeanHeight = 110.dp
    val GapAfterBean = 18.dp
    
    // Card dimensions
    val CardCornerRadius = 20.dp
    val SmallCardCornerRadius = 12.dp

    // Tekst
    val BeanLabelSize = 16.sp
    
    // Spacing constants
    val SpacingXS = 4.dp
    val SpacingS = 8.dp
    val SpacingM = 16.dp
    val SpacingL = 24.dp
    val SpacingXL = 32.dp
}

@Composable
fun BeanCTA(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        CoffeeBeanImageButton(
            text = "",
            onClick = onClick,
            width = GataUI.BeanWidth,
            height = GataUI.BeanHeight,
            preciseHit = false  // Omogući klik bilo gdje na gumbu
        )
        Spacer(Modifier.height(GataUI.GapAfterBean))
        Text(
            text = label,
            style = MaterialTheme.typography.titleLarge.copy(
                fontSize = GataUI.BeanLabelSize,
                color = GataUI.Beige
            )
        )
    }
}

package com.gatalinka.app.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.gatalinka.app.ui.theme.MysticPurpleDeep
import com.gatalinka.app.ui.theme.MysticPurpleMedium
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun MysticBackground(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "background_anim")
    
    // Animiraj offset za gradijent
    val offset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(20000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "offset"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(
                        MysticPurpleMedium,
                        MysticPurpleDeep
                    ),
                    center = Offset(500f + offset, 500f + offset),
                    radius = 1500f
                )
            )
    ) {
        // Dodaj zvijezde/iskrice
        Sparkles()
        
        // Sadržaj ekrana
        content()
        
        // Dim na dnu (overlay)
        SmokeEffect(modifier = Modifier.fillMaxSize())
    }
}

@Composable
fun Sparkles() {
    val infiniteTransition = rememberInfiniteTransition(label = "sparkles")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )
    
    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height
        
        // Nacrtaj par statičnih "zvijezda" koje trepere
        repeat(20) {
            val x = Random.nextFloat() * width
            val y = Random.nextFloat() * height
            drawCircle(
                color = Color.White.copy(alpha = alpha * Random.nextFloat()),
                radius = Random.nextFloat() * 3f,
                center = Offset(x, y)
            )
        }
    }
}

@Composable
fun SmokeEffect(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "smoke")
    val time by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(10000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "time"
    )

    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height
        
        // Crtaj "dim" kao seriju prozirnih krugova koji se miču sinusno
        val smokeColor = Color.Gray.copy(alpha = 0.1f)
        
        for (i in 0..5) {
            val xBase = width * (0.2f + 0.15f * i)
            val yBase = height * 0.9f
            
            val xOffset = sin(time + i) * 50f
            val yOffset = -((time * 50f + i * 100f) % (height * 0.5f))
            
            val radius = 50f + i * 20f + sin(time * 2) * 10f
            
            drawCircle(
                color = smokeColor,
                radius = radius,
                center = Offset(xBase + xOffset, yBase + yOffset)
            )
        }
    }
}

﻿package com.gatalinka.app.nav

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.*
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.gatalinka.app.data.UserPreferencesRepository
import com.gatalinka.app.ui.screens.*

@Composable
fun AppNavHost(
    nav: NavHostController,
    preferencesRepo: UserPreferencesRepository,
    startDestination: String
) {
    NavHost(navController = nav, startDestination = startDestination) {
        composable(Routes.Home) {
            HomeScreen(
                onReadCup = { nav.navigate(Routes.CupEditor) },
                onMyReadings = { nav.navigate(Routes.MyReadings) },
                onSchool = { nav.navigate(Routes.SchoolOfReading) },
                onLogin = { nav.navigate(Routes.Login) },
                onProfile = { nav.navigate(Routes.Profile) }
            )
        }
        composable(Routes.Login) {
            val hasCompletedOnboarding by preferencesRepo.hasCompletedOnboarding.collectAsState(initial = false)
            
            LoginScreen(
                onBack = { 
                    // Ne može ići nazad ako nije prijavljen
                    // Ako je prijavljen, već bi trebao biti na Home
                },
                onLoginSuccess = {
                    // Provjeri da li je korisnik završio onboarding
                    if (hasCompletedOnboarding) {
                        // Ako je završio onboarding, idi na Home
                        nav.navigate(Routes.Home) {
                            popUpTo(Routes.Login) { inclusive = true }
                        }
                    } else {
                        // Ako nije završio onboarding, idi na Onboarding
                        nav.navigate(Routes.Onboarding) {
                            popUpTo(Routes.Login) { inclusive = true }
                        }
                    }
                },
                onNavigateToRegister = { nav.navigate(Routes.Register) }
            )
        }
        composable(Routes.Register) {
            RegisterScreen(
                onBack = { nav.popBackStack() },
                onRegisterSuccess = {
                    // Nakon registracije, idi na Onboarding za unos datuma i spola
                    nav.popBackStack()
                    nav.navigate(Routes.Onboarding)
                },
                onNavigateToLogin = { nav.navigate(Routes.Login) }
            )
        }
        composable(Routes.Onboarding) {
            OnboardingScreen(
                preferencesRepo = preferencesRepo,
                onComplete = {
                    // Nakon onboardinga, idi na Home
                    nav.navigate(Routes.Home) {
                        popUpTo(Routes.Login) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.CupEditor) {
            CupEditorScreen(
                onBack = { nav.popBackStack() },
                onAnalyze = { imageUri ->
                    // Navigiraj na ReadCupScreen gdje će se pozvati API
                    val encodedUri = java.net.URLEncoder.encode(imageUri.toString(), "UTF-8")
                    nav.navigate("${Routes.ReadCup}/$encodedUri")
                }
            )
        }
        composable("${Routes.ReadCup}/{imageUri}") { backStackEntry ->
            val encodedUri = backStackEntry.arguments?.getString("imageUri") ?: ""
            val imageUri = try {
                java.net.URLDecoder.decode(encodedUri, "UTF-8")
            } catch (e: Exception) {
                encodedUri
            }
            ReadCupScreen(
                imageUri = imageUri,
                preferencesRepo = preferencesRepo,
                onBack = { nav.popBackStack() },
                onViewResult = { result ->
                    android.util.Log.d("AppNavHost", "onViewResult pozvan! luckScore=${result.luckScore}")
                    // Spremi rezultat u savedStateHandle trenutnog ekrana
                    backStackEntry.savedStateHandle["readingResult"] = result
                    android.util.Log.d("AppNavHost", "Rezultat spremljen u savedStateHandle")
                    
                    // Navigiraj na ReadingResult
                    val encodedResultUri = java.net.URLEncoder.encode(imageUri, "UTF-8")
                    android.util.Log.d("AppNavHost", "Navigiram na ReadingResult: ${Routes.ReadingResult}/$encodedResultUri")
                    nav.navigate("${Routes.ReadingResult}/$encodedResultUri")
                    android.util.Log.d("AppNavHost", "Navigacija pozvana")
                }
            )
        }
        composable("${Routes.ReadingResult}/{imageUri}") { backStackEntry ->
            val encodedUri = backStackEntry.arguments?.getString("imageUri") ?: ""
            val resultImageUri = try {
                java.net.URLDecoder.decode(encodedUri, "UTF-8")
            } catch (e: Exception) {
                encodedUri
            }
            
            // Čitaj rezultat iz savedStateHandle prethodnog ekrana
            val savedStateHandle = nav.previousBackStackEntry?.savedStateHandle
            var result by remember { mutableStateOf<com.gatalinka.app.ui.model.GatalinkaReadingUiModel?>(null) }
            
            // Pokušaj dohvatiti rezultat
            LaunchedEffect(Unit) {
                android.util.Log.d("AppNavHost", "ReadingResultScreen: Pokušavam dohvatiti rezultat iz savedStateHandle")
                android.util.Log.d("AppNavHost", "previousBackStackEntry: ${nav.previousBackStackEntry?.destination?.route}")
                val readingResult = savedStateHandle?.get<com.gatalinka.app.ui.model.GatalinkaReadingUiModel>("readingResult")
                android.util.Log.d("AppNavHost", "Rezultat dohvaćen: ${if (readingResult != null) "DA (luckScore=${readingResult.luckScore})" else "NE"}")
                result = readingResult
                if (readingResult == null) {
                    android.util.Log.e("AppNavHost", "❌ Rezultat nije pronađen! Vraćam se nazad.")
                    // Ako nema rezultata, vrati se nazad
                    nav.popBackStack()
                } else {
                    android.util.Log.d("AppNavHost", "✅ Rezultat pronađen! Prikazujem ReadingResultScreen")
                }
            }
            
            val currentResult = result
            if (currentResult != null) {
                ReadingResultScreen(
                    result = currentResult,
                    imageUri = resultImageUri,
                    onBack = { nav.popBackStack() },
                    onSave = { 
                        nav.popBackStack(Routes.Home, inclusive = false)
                        nav.navigate(Routes.Home)
                    }
                )
            } else {
                // Prikaži loading dok čekamo rezultat
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    androidx.compose.material3.CircularProgressIndicator()
                }
            }
        }
        composable(Routes.MyReadings) {
            MyReadingsScreen(
                onBack = { nav.popBackStack() },
                onReadingClick = { readingId ->
                    nav.navigate("${Routes.SavedReading}/$readingId")
                }
            )
        }
        composable("${Routes.SavedReading}/{readingId}") { backStackEntry ->
            val readingId = backStackEntry.arguments?.getString("readingId") ?: ""
            val readingsRepo = remember { com.gatalinka.app.data.CloudReadingsRepository() }
            var reading by remember { mutableStateOf<com.gatalinka.app.data.CupReading?>(null) }
            var isLoading by remember { mutableStateOf(true) }
            var error by remember { mutableStateOf<String?>(null) }
            
            LaunchedEffect(readingId) {
                isLoading = true
                error = null
                try {
                    reading = readingsRepo.getReadingById(readingId)
                    if (reading == null) {
                        error = "Čitanje nije pronađeno"
                    }
                } catch (e: Exception) {
                    error = "Greška pri učitavanju: ${e.message}"
                    android.util.Log.e("AppNavHost", "Error loading reading", e)
                } finally {
                    isLoading = false
                }
            }
            
            when {
                isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        androidx.compose.material3.CircularProgressIndicator()
                    }
                }
                error != null -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(24.dp)
                        ) {
                            androidx.compose.material3.Text(
                                text = error ?: "Greška",
                                color = androidx.compose.ui.graphics.Color(0xFFFFD700),
                                style = androidx.compose.material3.MaterialTheme.typography.titleMedium
                            )
                            Spacer(Modifier.height(16.dp))
                            androidx.compose.material3.Button(
                                onClick = { nav.popBackStack() }
                            ) {
                                androidx.compose.material3.Text("Nazad")
                            }
                        }
                    }
                }
                reading != null -> {
                    val uiModel = com.gatalinka.app.data.ReadingMapper.mapToUiModel(reading!!)
                    ReadingResultScreen(
                        result = uiModel,
                        imageUri = reading!!.imageUri,
                        onBack = { nav.popBackStack() },
                        onSave = { nav.popBackStack() }
                    )
                }
            }
        }
        composable(Routes.SchoolOfReading) {
            SchoolOfReadingScreen(
                onBack = { nav.popBackStack() }
            )
        }
        composable(Routes.Profile) {
            ProfileScreen(
                onBack = { nav.popBackStack() },
                onSettings = { nav.navigate(Routes.Settings) }
            )
        }
        composable(Routes.Settings) {
            SettingsScreen(
                onBack = { nav.popBackStack() },
                onSignOut = {
                    // Nakon odjave, idi na Login i očisti back stack
                    nav.navigate(Routes.Login) {
                        popUpTo(Routes.Login) { inclusive = true }
                    }
                }
            )
        }
    }
}

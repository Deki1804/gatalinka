package com.gatalinka.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gatalinka.app.ui.design.GataUI

data class SchoolCard(
    val title: String,
    val content: String,
    val emoji: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SchoolOfReadingScreen(
    onBack: () -> Unit
) {
    val cards = remember {
        listOf(
            SchoolCard(
                title = "Kako se kuha najbolja kava",
                emoji = "☕",
                content = """
                    ZA NAJBOLJU KAVU:
                    
                    1. KORISTI KVALITETNU KAVU
                    • Odaberi fino mljevenu tursku kavu
                    • Svježe mljevena kava daje najbolji talog
                    • Izbjegavaj instant kavu
                    
                    2. PRAVILNA KOLIČINA
                    • 1-2 žličice po šalici (po želji)
                    • Ne previše - talog će biti pregust
                    • Ne premalo - neće biti dovoljno simbola
                    
                    3. TEMPERATURA VODE
                    • Vruća voda, ali ne kipuća (90-95°C)
                    • Kipuća voda sprži kavu
                    • Hladna voda neće ekstrahirati dovoljno
                    
                    4. KUHANJE
                    • Kratko prokuvaj na niskoj vatri
                    • Ne miješaj dok se kuha
                    • Ostavi da se talog slegne 1-2 minute
                    
                    5. SERVIRANJE
                    • Ulij u šalicu, ostavi talog na dnu
                    • Ne pij sve - ostavi talog za čitanje!
                """.trimIndent()
            ),
            SchoolCard(
                title = "Okretanje šalice",
                emoji = "🔄",
                content = """
                    PRAVILNO OKRETANJE:
                    
                    1. POPIJ KAVU
                    • Popij kavu, ali ostavi talog na dnu
                    • Ne miješaj talog dok piješ
                    • Ostavi oko 1 cm taloga
                    
                    2. POKRI ŠALICU
                    • Pokrij šalicu tanjurčićem ili tanjurom
                    • Ovo osigurava da se talog ne rasprši
                    • Važno za dobar rezultat!
                    
                    3. OKRENI ŠALICU
                    • Okreni šalicu naglavačke (180°)
                    • Drži poklopac pritisnut
                    • Čekaj 2-3 minute da se talog slegne
                    
                    4. PAŽLJIVO OKRENI NATRAG
                    • Polako okreni šalicu natrag
                    • Ne tresi šalicu
                    • Talog će ostaviti oblike na stijenkama
                    
                    5. ANALIZIRAJ
                    • Gledaj oblike i simbole
                    • Svaki oblik ima značenje
                    • Fotkaj za AI analizu!
                """.trimIndent()
            ),
            SchoolCard(
                title = "Simboli i značenja",
                emoji = "🔮",
                content = """
                    OSNOVNI SIMBOLI:
                    
                    LJUBAV I EMOCIJE:
                    • Srce - ljubav, romansa, emocionalna povezanost
                    • Cvijet - nova ljubav, rast, cvatnja
                    • Prsten - brak, obećanje, cjelovitost
                    
                    USPJEH I KARIJERA:
                    • Zvijezda - uspjeh, realizacija snova
                    • Krunica - dostignuće, priznanje
                    • Strelica - napredak, smjer, akcija
                    
                    PUTOVANJE I PROMJENE:
                    • Linija - putovanje, promjene u životu
                    • Most - prelazak, nova faza
                    • Put - životni put, putovanje
                    
                    NOVAC I MATERIJALNO:
                    • Točkice - novac, materijalna dobra
                    • Krug - cjelovitost, ciklusi
                    • Kvadrat - stabilnost, sigurnost
                    
                    NEJASNOĆA:
                    • Oblak - nejasnoća, strpljenje
                    • Magla - neizvjesnost, čekanje
                """.trimIndent()
            ),
            SchoolCard(
                title = "Bapske priče - Povijest",
                emoji = "📖",
                content = """
                    TRADICIJA GATANJA IZ KAVE:
                    
                    Gatanje iz kave (turski: kahve falı) je stara tradicija koja potječe iz Osmanskog Carstva u 16. stoljeću. Babe su prenosile znanje kroz generacije, tumačeći oblike u talogu kave.
                    
                    KAKO JE SVE POČELO:
                    • Turska kava je stigla u Istanbul 1550-ih
                    • Gatanje se razvilo kao zabavna aktivnost
                    • Postalo je dio kulture i tradicije
                    
                    BABE I TRADICIJA:
                    • Babe su bile majstorice gatanja
                    • Prenosile su znanje kćerima i unukama
                    • Svaka baba imala je svoje tumačenje
                    
                    MODERNA DOBA:
                    • Tradicija se nastavlja i danas
                    • AI tehnologija pomaže u analizi
                    • Kombinacija stare mudrosti i moderne znanosti
                    
                    Svaka šalica priča jedinstvenu priču o sudbini, ljubavi i budućnosti!
                """.trimIndent()
            ),
            SchoolCard(
                title = "Bapske priče - Mudrost",
                emoji = "🧙",
                content = """
                    MUDROST BABE:
                    
                    "Šalica kave je kao knjiga - svaki oblik je stranica koja priča priču o tvom životu."
                    
                    ZLATNA PRAVILA:
                    • Čitaj šalicu u miru i tišini
                    • Ne forsiraj tumačenje - simboli će se pokazati
                    • Svaka šalica je jedinstvena
                    • Ne čitaj previše često - jednom dnevno je dovoljno
                    
                    KADA ČITATI:
                    • Ujutro - za dnevne savjete
                    • Nakon važnih događaja
                    • Kada tražiš odgovore
                    • Za zabavu s prijateljima
                    
                    ŠTO IZBJEGAVATI:
                    • Ne čitaj kada si uznemiren
                    • Ne traži samo loše znakove
                    • Ne očekuj točne datume
                    • Ne uzimaj sve doslovno
                    
                    "Gatanje nije predviđanje - to je razmišljanje o mogućnostima."
                """.trimIndent()
            ),
            SchoolCard(
                title = "Horoskopski savjeti",
                emoji = "⭐",
                content = """
                    ZNAKOVI I SIMBOLI:
                    
                    VATRENI ZNAKOVI (Ovan, Lav, Strijelac):
                    • Traži dinamične oblike, linije koje idu naprijed
                    • Zvijezde i strelice su tvoji znakovi
                    • Jaki, jasni simboli znače akciju
                    
                    ZEMLJANI ZNAKOVI (Bik, Djevica, Jarac):
                    • Fokusiraj se na stabilne oblike
                    • Kvadrati i krugovi su tvoji znakovi
                    • Simetrija znači balans
                    
                    ZRAČNI ZNAKOVI (Blizanci, Vaga, Vodenjak):
                    • Traži simetriju i balans u šalici
                    • Oblaci i magla mogu značiti promjene
                    • Linije znače komunikaciju
                    
                    VODENI ZNAKOVI (Rak, Škorpion, Ribe):
                    • Traži duboke, intenzivne oblike
                    • Srca i cvijetovi su tvoji znakovi
                    • Mekani, fluidni oblici su tvoji znakovi
                    
                    Svaki znak ima svoje karakteristične simbole!
                """.trimIndent()
            ),
            SchoolCard(
                title = "Napredni savjeti",
                emoji = "🎯",
                content = """
                    ZA NAJBOLJE REZULTATE:
                    
                    FOTOGRAFIJANJE:
                    • Fotkaj šalicu odozgo, direktno
                    • Dobra svjetlost je ključna
                    • Ukloni sve što ometa (tanjur, žličica)
                    • Šalica treba biti u centru okvira
                    
                    KVALITETA SLIKE:
                    • Jasna, oštra slika
                    • Dobar kontrast između taloga i šalice
                    • Ne previše svijetlo ili tamno
                    • Približi se šalici
                    
                    KADA FOTKATI:
                    • Nakon što se talog slegne (2-3 min)
                    • Prije nego što se talog počne raspadati
                    • U dobrom svjetlu
                    
                    TIPOVI ŠALICA:
                    • Bijele šalice su najbolje
                    • Široke šalice daju više prostora za simbole
                    • Duboke šalice daju više detalja
                    
                    AI će analizirati sve simbole i dati ti detaljno čitanje!
                """.trimIndent()
            )
        )
    }

    var currentPage by remember { mutableStateOf(0) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF1A0B2E), // Mystic Purple Deep
                        Color(0xFF2D1B4E)  // Mystic Purple Medium
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Top Bar
            TopAppBar(
                title = {
                    Text(
                        "Škola gatanja",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color(0xFFFFD700)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            "Nazad",
                            tint = Color(0xFFEFE3D1)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
            ) {
            // Card content
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .pointerInput(Unit) {
                        detectHorizontalDragGestures { change, dragAmount ->
                            if (dragAmount > 50 && currentPage > 0) {
                                currentPage--
                            } else if (dragAmount < -50 && currentPage < cards.size - 1) {
                                currentPage++
                            }
                        }
                    }
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                        .padding(vertical = 16.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFF2D1B4E).copy(alpha = 0.9f)
                    )
                ) {
                    val scrollState = rememberScrollState()
                    
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(scrollState)
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = cards[currentPage].emoji,
                            fontSize = 64.sp,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )
                        
                        Text(
                            text = cards[currentPage].title,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFD700),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(bottom = 24.dp)
                        )

                        Text(
                            text = cards[currentPage].content,
                            style = MaterialTheme.typography.bodyLarge,
                            color = Color(0xFFEFE3D1),
                            textAlign = TextAlign.Justify,
                            lineHeight = 24.sp
                        )
                        
                        // Extra padding at bottom for better scrolling
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }

            // Page indicator and navigation
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        if (currentPage > 0) {
                            currentPage--
                        }
                    },
                    enabled = currentPage > 0
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack, 
                        "Prethodna",
                        tint = if (currentPage > 0) Color(0xFFFFD700) else Color(0xFFEFE3D1).copy(alpha = 0.3f)
                    )
                }

                // Page dots
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    repeat(cards.size) { index ->
                        Box(
                            modifier = Modifier
                                .size(if (currentPage == index) 12.dp else 8.dp)
                                .background(
                                    color = if (currentPage == index)
                                        Color(0xFFFFD700)
                                    else
                                        Color(0xFFEFE3D1).copy(alpha = 0.3f),
                                    shape = RoundedCornerShape(50)
                                )
                        )
                    }
                }

                IconButton(
                    onClick = {
                        if (currentPage < cards.size - 1) {
                            currentPage++
                        }
                    },
                    enabled = currentPage < cards.size - 1
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowForward, 
                        "Sljedeća",
                        tint = if (currentPage < cards.size - 1) Color(0xFFFFD700) else Color(0xFFEFE3D1).copy(alpha = 0.3f)
                    )
                }
            }
            }
        }
    }
}

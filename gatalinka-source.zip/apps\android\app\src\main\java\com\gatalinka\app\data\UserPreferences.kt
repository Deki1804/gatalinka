package com.gatalinka.app.data

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.booleanPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

object UserPreferencesKeys {
    val BIRTHDATE = stringPreferencesKey("birthdate")
    val GENDER = stringPreferencesKey("gender")
    val ZODIAC_SIGN = stringPreferencesKey("zodiac_sign")
    val HAS_COMPLETED_ONBOARDING = booleanPreferencesKey("has_completed_onboarding")
}

class UserPreferencesRepository(private val dataStore: DataStore<Preferences>) {
    
    val userInput: Flow<UserInput> = dataStore.data.map { preferences ->
        UserInput(
            birthdate = preferences[UserPreferencesKeys.BIRTHDATE] ?: "",
            gender = preferences[UserPreferencesKeys.GENDER]?.let { 
                try { Gender.valueOf(it) } catch (e: Exception) { Gender.Unspecified }
            } ?: Gender.Unspecified,
            zodiacSign = preferences[UserPreferencesKeys.ZODIAC_SIGN]?.let {
                try { com.gatalinka.app.util.ZodiacSign.valueOf(it) } catch (e: Exception) { null }
            }
        )
    }
    
    val hasCompletedOnboarding: Flow<Boolean> = dataStore.data.map { preferences ->
        val hasFlag = preferences[UserPreferencesKeys.HAS_COMPLETED_ONBOARDING] ?: false
        val hasBirthdate = !preferences[UserPreferencesKeys.BIRTHDATE].isNullOrEmpty()
        val hasGender = preferences[UserPreferencesKeys.GENDER] != null && 
                       preferences[UserPreferencesKeys.GENDER] != "Unspecified"
        // Onboarding je završen samo ako ima flag I ima datum I spol
        hasFlag && hasBirthdate && hasGender
    }
    
    suspend fun saveUserInput(input: UserInput) {
        dataStore.edit { preferences ->
            preferences[UserPreferencesKeys.BIRTHDATE] = input.birthdate
            preferences[UserPreferencesKeys.GENDER] = input.gender.name
            input.zodiacSign?.let {
                preferences[UserPreferencesKeys.ZODIAC_SIGN] = it.name
            }
            preferences[UserPreferencesKeys.HAS_COMPLETED_ONBOARDING] = true
        }
    }
    
    suspend fun clearOnboarding() {
        dataStore.edit { preferences ->
            preferences[UserPreferencesKeys.HAS_COMPLETED_ONBOARDING] = false
        }
    }
}






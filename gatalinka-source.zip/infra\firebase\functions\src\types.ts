﻿export interface ReadingResponse {
  main_text: string;
  love: string;
  work: string;
  money: string;
  health: string;
  symbols: string[];
  lucky_numbers: number[];
  luck_score: number;
  is_valid_cup: boolean;
  safety_level: "ok" | "nsfw" | "unknown";
  reason: string;
}

export interface FirestoreReading {
  userId: string;
  imageUrl: string;
  timestamp: FirebaseFirestore.Timestamp;
  zodiacSign: string | null;
  gender: string | null;
  focusArea: string | null;
  reading: ReadingResponse;
  createdAt: Date;
}
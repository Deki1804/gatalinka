package com.gatalinka.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.runtime.collectAsState
import com.gatalinka.app.vm.AuthViewModel

@Composable
fun HomeScreen(
    onReadCup: () -> Unit,
    onMyReadings: () -> Unit = {},
    onSchool: () -> Unit = {},
    onLogin: () -> Unit = {},
    onProfile: () -> Unit = {}
) {
    val viewModel: AuthViewModel = viewModel()
    val authState by viewModel.authState.collectAsState()
    val isAuthenticated = authState is com.gatalinka.app.vm.AuthState.Authenticated
    
    // Ako nije prijavljen, automatski idi na Login
    androidx.compose.runtime.LaunchedEffect(authState) {
        if (authState !is com.gatalinka.app.vm.AuthState.Authenticated) {
            onLogin()
        }
    }
    
    // Animacija za pulsiranje dugmeta
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF1A0B2E), // Mystic Purple Deep
                        Color(0xFF2D1B4E)  // Mystic Purple Medium
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top section - Logo/Title
            Spacer(modifier = Modifier.height(60.dp))
            
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 40.dp)
            ) {
                Text(
                    text = "Gatalinka",
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontSize = 48.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFD700) // Mystic Gold
                    ),
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = "Otkrivaj sudbinu u šalici kafe",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        color = Color(0xFFEFE3D1).copy(alpha = 0.8f) // Mystic Text Light
                    ),
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // Center - Main Action Button (samo ako je prijavljen)
            if (isAuthenticated) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(vertical = 40.dp)
                ) {
                    FloatingActionButton(
                        onClick = onReadCup,
                        modifier = Modifier
                            .size(120.dp)
                            .scale(scale),
                        containerColor = Color(0xFFFFD700), // Mystic Gold
                        contentColor = Color(0xFF1A0B2E), // Dark purple
                        shape = CircleShape
                    ) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = "Fotkaj šalicu",
                            modifier = Modifier.size(56.dp),
                            tint = Color(0xFF1A0B2E)
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    Text(
                        text = "Fotkaj šalicu",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFD700)
                        )
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = "AI će otkriti tvoju sudbinu",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Color(0xFFEFE3D1).copy(alpha = 0.7f)
                        ),
                        textAlign = TextAlign.Center
                    )
                    
                    Spacer(modifier = Modifier.height(32.dp))
                    
                    // Quick access buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        TextButton(
                            onClick = onMyReadings,
                            colors = ButtonDefaults.textButtonColors(
                                contentColor = Color(0xFFFFD700)
                            )
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("📖", fontSize = 24.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    "Moja čitanja",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                        
                        TextButton(
                            onClick = onSchool,
                            colors = ButtonDefaults.textButtonColors(
                                contentColor = Color(0xFFFFD700)
                            )
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("📚", fontSize = 24.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    "Škola",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            } else {
                // Ako nije prijavljen, prikaži poruku
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(vertical = 40.dp)
                ) {
                    Text(
                        text = "Prijavi se da nastaviš",
                        style = MaterialTheme.typography.bodyLarge.copy(
                            color = Color(0xFFEFE3D1).copy(alpha = 0.7f)
                        ),
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Bottom - Profile or Login
            if (isAuthenticated) {
                // Profile button - ako je prijavljen
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 32.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    TextButton(
                        onClick = onProfile
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = Color(0xFFFFD700)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = when (val state = authState) {
                                    is com.gatalinka.app.vm.AuthState.Authenticated -> {
                                        state.displayName ?: state.email?.split("@")?.first() ?: "Profil"
                                    }
                                    else -> "Profil"
                                },
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = Color(0xFFFFD700),
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }
                    }
                }
            } else {
                // Login button - ako nije prijavljen
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 32.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    TextButton(
                        onClick = onLogin
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = Color(0xFFFFD700)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Prijavi se",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = Color(0xFFFFD700),
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
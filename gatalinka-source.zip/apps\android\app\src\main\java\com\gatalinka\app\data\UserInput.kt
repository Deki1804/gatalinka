﻿package com.gatalinka.app.data

import com.gatalinka.app.util.ZodiacSign

data class UserInput(
    val birthdate: String = "",
    val gender: Gender = Gender.Unspecified,
    val zodiacSign: ZodiacSign? = null,
    val acceptedDisclaimer: Boolean = false
)

enum class Gender { Male, Female, Other, Unspecified }

data class CupReading(
    val id: String = java.util.UUID.randomUUID().toString(),
    val imageUri: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val symbols: List<String> = emptyList(),
    val interpretation: ReadingInterpretation = ReadingInterpretation(),
    val happinessScore: Int = 0,
    val luckyNumbers: List<Int> = emptyList(),
    val advice: String = "",
    val zodiacContext: String = ""
)

data class ReadingInterpretation(
    val love: String = "",
    val career: String = "",
    val money: String = "",
    val health: String = "",
    val future: String = ""
)

package com.gatalinka.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import kotlinx.coroutines.launch
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReadingResultScreen(
    result: com.gatalinka.app.ui.model.GatalinkaReadingUiModel,
    imageUri: String,
    onBack: () -> Unit,
    onSave: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val readingsRepo = remember { com.gatalinka.app.data.CloudReadingsRepository() }
    
    var isSaving by remember { mutableStateOf(false) }
    var saveError by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF1A0B2E), // Mystic Purple Deep
                        Color(0xFF2D1B4E)  // Mystic Purple Medium
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Top Bar
            TopAppBar(
                title = {
                    Text(
                        "Tvoja sudbina",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color(0xFFFFD700)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            "Nazad",
                            tint = Color(0xFFEFE3D1)
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { /* TODO: Share */ }) {
                        Icon(
                            Icons.Default.Share,
                            "Dijeli",
                            tint = Color(0xFFEFE3D1)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )

            // Content
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 24.dp)
            ) {
                Spacer(modifier = Modifier.height(16.dp))

                // Luck Score Card
                LuckScoreCard(result.luckScore)

                Spacer(modifier = Modifier.height(24.dp))

                // Main Reading Text
                ReadingCard(
                    title = "Priča iz šalice",
                    content = result.mainText
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Categories
                if (result.love?.isNotEmpty() == true) {
                    ReadingCard(
                        title = "💕 Ljubav",
                        content = result.love
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                }
                if (result.work?.isNotEmpty() == true) {
                    ReadingCard(
                        title = "💼 Posao",
                        content = result.work
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                }
                if (result.money?.isNotEmpty() == true) {
                    ReadingCard(
                        title = "💰 Novac",
                        content = result.money
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                }
                if (result.health?.isNotEmpty() == true) {
                    ReadingCard(
                        title = "🌿 Zdravlje",
                        content = result.health
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Symbols
                if (result.symbols.isNotEmpty()) {
                    SymbolsCard(result.symbols)
                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Lucky Numbers
                if (result.luckyNumbers.isNotEmpty()) {
                    LuckyNumbersCard(result.luckyNumbers)
                    Spacer(modifier = Modifier.height(24.dp))
                }

                // Error message
                if (saveError != null) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xFFFF6B6B).copy(alpha = 0.9f)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            saveError ?: "Greška pri spremanju",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
                
                // Save Button
                Button(
                    onClick = {
                        val currentImageUri = imageUri.split("?")[0]
                        coroutineScope.launch {
                            isSaving = true
                            saveError = null
                            try {
                                val cupReading = com.gatalinka.app.data.ReadingMapper.mapToCupReading(
                                    result,
                                    currentImageUri
                                )
                                readingsRepo.addReading(cupReading)
                                onSave()
                            } catch (e: Exception) {
                                saveError = when {
                                    e.message?.contains("PERMISSION_DENIED", ignoreCase = true) == true ||
                                    e.message?.contains("permission", ignoreCase = true) == true ->
                                        "Nemate dozvolu za spremanje. Provjerite da ste prijavljeni."
                                    e.message?.contains("network", ignoreCase = true) == true ->
                                        "Ne mogu se spojiti na server. Provjeri internetsku vezu."
                                    else ->
                                        "Greška pri spremanju: ${e.message ?: e.javaClass.simpleName}"
                                }
                                android.util.Log.e("ReadingResultScreen", "Error saving reading", e)
                            } finally {
                                isSaving = false
                            }
                        }
                    },
                    enabled = !isSaving,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFFD700),
                        contentColor = Color(0xFF1A0B2E),
                        disabledContainerColor = Color(0xFFFFD700).copy(alpha = 0.6f)
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    if (isSaving) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = Color(0xFF1A0B2E),
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text(
                            "Spremi čitanje",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LuckScoreCard(score: Int) {
    val infiniteTransition = rememberInfiniteTransition(label = "glow")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFFFD700).copy(alpha = glowAlpha)
        ),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Sreća",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1A0B2E)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "$score/100",
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 56.sp,
                    fontWeight = FontWeight.Bold
                ),
                color = Color(0xFF1A0B2E)
            )
            Spacer(modifier = Modifier.height(16.dp))
            LinearProgressIndicator(
                progress = { score / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(12.dp)
                    .clip(RoundedCornerShape(6.dp)),
                color = Color(0xFF1A0B2E),
                trackColor = Color(0xFF1A0B2E).copy(alpha = 0.3f)
            )
        }
    }
}

@Composable
fun ReadingCard(title: String, content: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF2D1B4E).copy(alpha = 0.8f)
        ),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Text(
                title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFFFD700),
                modifier = Modifier.padding(bottom = 12.dp)
            )
            Text(
                content,
                style = MaterialTheme.typography.bodyLarge,
                color = Color(0xFFEFE3D1),
                lineHeight = 24.sp,
                textAlign = TextAlign.Justify
            )
        }
    }
}

@Composable
fun SymbolsCard(symbols: List<String>) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF2D1B4E).copy(alpha = 0.8f)
        ),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Text(
                "Prepoznati simboli",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFFFD700),
                modifier = Modifier.padding(bottom = 12.dp)
            )
            symbols.forEach { symbol ->
                Row(
                    modifier = Modifier.padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "✦",
                        color = Color(0xFFFFD700),
                        modifier = Modifier.padding(end = 12.dp)
                    )
                    Text(
                        symbol,
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color(0xFFEFE3D1)
                    )
                }
            }
        }
    }
}

@Composable
fun LuckyNumbersCard(numbers: List<Int>) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF2D1B4E).copy(alpha = 0.8f)
        ),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Sretni brojevi",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFFFD700),
                modifier = Modifier.padding(bottom = 16.dp)
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                numbers.forEach { number ->
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFFFFD700),
                        modifier = Modifier.size(60.dp),
                        shadowElevation = 8.dp
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Text(
                                number.toString(),
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1A0B2E)
                            )
                        }
                    }
                }
            }
        }
    }
}

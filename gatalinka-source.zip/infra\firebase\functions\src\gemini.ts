﻿import { GoogleGenerativeAI } from "@google/generative-ai";
import * as functions from "firebase-functions";

function getGeminiApiKey(): string {
    try {
        const config = functions.config();
        if (config?.gemini?.api_key) {
            return config.gemini.api_key;
        }
    } catch (e) {
    }
    
    return process.env.GEMINI_API_KEY || "";
}

export interface GeminiReadingResult {
  main_text: string;
  love: string;
  work: string;
  money: string;
  health: string;
  symbols: string[];
  lucky_numbers: number[];
  luck_score: number;
}

export async function generateReadingWithGemini(
  imageBuffer: Buffer,
  zodiacSign?: string,
  gender?: string,
  focusArea?: string
): Promise<GeminiReadingResult> {
  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    throw new Error("Gemini API nije konfiguriran. Postavite functions config ili GEMINI_API_KEY environment varijablu.");
  }
  
  const genAI = new GoogleGenerativeAI(apiKey);

  try {
    // 1.5 modeli su povučeni – koristimo preporučeni 2.x model
    // Prema novim pravilima treba koristiti gemini-2.0-flash za multimodalne zadatke
    const model = genAI.getGenerativeModel({
      model: "gemini-2.0-flash",
    });
    const prompt = buildPrompt(zodiacSign, gender, focusArea);
    const imageBase64 = imageBuffer.toString("base64");
    const imageData = {
      inlineData: {
        data: imageBase64,
        mimeType: "image/jpeg",
      },
    };

    console.log("Calling Gemini API for coffee cup reading...");
    const result = await model.generateContent([prompt, imageData]);
    const response = await result.response;
    const text = response.text();

    console.log(`Gemini response length: ${text.length} characters`);
    const parsed = parseGeminiResponse(text);
    return parsed;
  } catch (error: any) {
    console.error("Gemini API error:", error);
    throw new Error(`Greška pri generiranju čitanja: ${error.message}`);
  }
}

function parseGeminiResponse(text: string): GeminiReadingResult {
  let cleaned = text;
  if (cleaned.includes("```json")) {
    cleaned = cleaned.replace(/```json/g, "").replace(/```/g, "").trim();
  } else if (cleaned.includes("```")) {
    cleaned = cleaned.replace(/```/g, "").trim();
  }

  const jsonStart = cleaned.indexOf("{");
  const jsonEnd = cleaned.lastIndexOf("}");

  if (jsonStart === -1 || jsonEnd === -1 || jsonEnd <= jsonStart) {
    throw new Error("Gemini API nije vratio validan JSON odgovor.");
  }

  const jsonText = cleaned.substring(jsonStart, jsonEnd + 1);

  try {
    const parsed = JSON.parse(jsonText);
    
    // Log raw luck_score iz Gemini response
    console.log("Raw luck_score from Gemini:", parsed.luck_score);
    console.log("Type of luck_score:", typeof parsed.luck_score);

    const finalLuckScore = typeof parsed.luck_score === "number"
      ? Math.max(0, Math.min(100, parsed.luck_score))
      : generateLuckScore();
    
    console.log("Final luck_score after processing:", finalLuckScore);

    return {
      main_text: parsed.main_text || "",
      love: parsed.love || "",
      work: parsed.work || "",
      money: parsed.money || "",
      health: parsed.health || "",
      symbols: Array.isArray(parsed.symbols) ? parsed.symbols : [],
      lucky_numbers: Array.isArray(parsed.lucky_numbers)
        ? parsed.lucky_numbers
        : generateLuckyNumbers(),
      luck_score: finalLuckScore,
    };
  } catch (error: any) {
    console.error("Failed to parse Gemini JSON response:", error);
    console.error("Response text:", jsonText.substring(0, 500));
    throw new Error(`Nije moguće parsirati JSON odgovor: ${error.message}`);
  }
}

function buildPrompt(
  zodiacSign?: string,
  gender?: string,
  focusArea?: string
): string {
  const contextParts: string[] = [];
  if (zodiacSign) contextParts.push(`Korisnikov znak zodijaka: ${zodiacSign}`);
  if (gender) contextParts.push(`Spol: ${gender}`);
  if (focusArea) contextParts.push(`Područje fokusa: ${focusArea}`);

  const contextStr = contextParts.length > 0
    ? `\n${contextParts.join("\n")}\n`
    : "";

  return `
Ti si stara, mistična gatarica koja čita iz taloga kave (Tasseografija).
Pogledaj ovu sliku šalice kave. Identificiraj oblike i simbole u talogu.
${contextStr}
Na temelju onoga što vidiš, generiraj čitanje na hrvatskom jeziku.
Budi misteriozna, malo dramatična, ali u konačnici pozitivna i ohrabrujuća.

MORAŠ vratiti rezultat u VALIDAN JSON format sa sljedećom strukturom:
{
    "main_text": "Paragraf koji opisuje opću energiju i ono što vidiš u šalici.",
    "love": "Tumačenje vezano uz ljubav i veze.",
    "work": "Tumačenje vezano uz karijeru i uspjeh.",
    "money": "Tumačenje vezano uz financije.",
    "health": "Tumačenje vezano uz vitalnost i energiju.",
    "symbols": ["Lista", "od", "3-5", "simbola", "koje", "identificiraš"],
    "luck_score": <broj od 0 do 100 koji odražava opću sreću i pozitivnu energiju u šalici>,
    "lucky_numbers": [1, 7, 12, 23, 45]
}

VAŽNO: luck_score mora biti različit za svaku šalicu ovisno o onome što vidiš. 
Analiziraj oblike, simbole i opću energiju te dodijeli odgovarajući score (0-100).
Ne koristi uvijek isti broj!

Ne uključuj nikakav tekst izvan JSON objekta.
`;
}

function generateLuckyNumbers(): number[] {
  const numbers: number[] = [];
  while (numbers.length < 5) {
    const num = Math.floor(Math.random() * 49) + 1;
    if (!numbers.includes(num)) {
      numbers.push(num);
    }
  }
  return numbers.sort((a, b) => a - b);
}

function generateLuckScore(): number {
  return Math.floor(Math.random() * 40) + 50;
}
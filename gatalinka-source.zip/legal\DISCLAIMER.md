﻿# Odricanje od odgovornosti (Disclaimer)

Gatalinka je isključivo **zabavnog karaktera**. 
Tumačenja iz šalice ne predstavljaju stvarno proricanje sudbine.
Ne donositi financijske, medicinske ili druge važne odluke isključivo na temelju rezultata.

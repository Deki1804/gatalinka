package com.gatalinka.app.ui.screens

import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gatalinka.app.R
import com.gatalinka.app.api.FirebaseFunctionsService
import com.gatalinka.app.api.dto.GatalinkaReadingDto
import com.gatalinka.app.data.UserPreferencesRepository
import com.gatalinka.app.ui.design.BeanCTA
import com.gatalinka.app.ui.design.GataUI
import com.gatalinka.app.ui.model.GatalinkaReadingUiModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@Composable
fun ReadCupScreen(
    imageUri: String,
    preferencesRepo: UserPreferencesRepository,
    onBack: () -> Unit,
    onViewResult: (GatalinkaReadingUiModel) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<GatalinkaReadingUiModel?>(null) }
    
    // Pokreni čitanje jednom
    LaunchedEffect(imageUri) {
        isLoading = true
        errorMessage = null
        result = null
        
        try {
            val cleanImageUri = imageUri.split("?")[0]
            val uri = Uri.parse(cleanImageUri)
            val userInput = preferencesRepo.userInput.first()
            
            val response = FirebaseFunctionsService.readCup(
                imageUri = uri,
                context = context,
                userInput = userInput
            )
            
            if (!response.isValidCup) {
                errorMessage = when (response.reason) {
                    "image_too_small", "image_too_small_dimensions" ->
                        "Fotografija je premala ili preniske kvalitete. Pokušaj približiti šalicu i slikati u boljem svjetlu."
                    "bad_aspect_ratio" ->
                        "Šalicu treba slikati odozgo, tako da bude unutar kružnog okvira. Pokušaj ponovo s pogleda odozgo."
                    "too_dark" ->
                        "Fotografija je previše tamna. Uključi svjetlo ili priđi bliže prozoru pa pokušaj ponovno."
                    "too_bright" ->
                        "Fotografija je previše svijetla. Pokušaj bez blica ili malo dalje od svjetla."
                    "low_contrast" ->
                        "Fotografija je mutna ili bez dovoljno detalja. Pokušaj ponovno, drži mobitel mirnije."
                    "analysis_failed" ->
                        "Nešto je pošlo po zlu prilikom analize slike. Pokušaj ponovno ili odaberi drugu fotografiju."
                    else ->
                        "Ova fotografija vjerojatno nije dobra za čitanje šalice. Pokušaj ponovno uz jasnu sliku šalice odozgo."
                }
                isLoading = false
                return@LaunchedEffect
            }
            
            if (response.safetyLevel == "nsfw" || response.reason == "nsfw_detected") {
                errorMessage = "Fotografija nije prikladna za čitanje šalice."
                isLoading = false
                return@LaunchedEffect
            }
            
            // Mapiraj u UI model
            val uiModel = GatalinkaReadingUiModel(
                mainText = response.mainText,
                love = response.love,
                work = response.work,
                money = response.money,
                health = response.health,
                symbols = response.symbols,
                luckyNumbers = response.luckyNumbers,
                luckScore = response.luckScore
            )
            
            result = uiModel
            isLoading = false
            
            android.util.Log.d("ReadCupScreen", "✅ Rezultat primljen! luckScore=${uiModel.luckScore}, mainText length=${uiModel.mainText.length}")
            android.util.Log.d("ReadCupScreen", "Pozivanje onViewResult...")
            
            // Navigiraj direktno
            onViewResult(uiModel)
            
            android.util.Log.d("ReadCupScreen", "onViewResult pozvan - navigacija bi trebala biti u tijeku")
            
        } catch (e: Exception) {
            errorMessage = when {
                e.message?.contains("prijavljen", ignoreCase = true) == true ||
                e.message?.contains("authenticated", ignoreCase = true) == true ||
                e.message?.contains("UNAUTHENTICATED", ignoreCase = true) == true ->
                    "Niste prijavljeni. Molimo prijavite se i pokušajte ponovo."
                e.message?.contains("timeout", ignoreCase = true) == true ->
                    "Vrijeme čekanja je isteklo. Pokušaj ponovo."
                e.message?.contains("network", ignoreCase = true) == true ->
                    "Ne mogu se spojiti na Gatalinku. Provjeri internetsku vezu."
                else ->
                    "Nešto je pošlo po zlu: ${e.message ?: e.javaClass.simpleName}"
            }
            isLoading = false
        }
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1E1510))
    ) {
        // Pozadina
        Image(
            painter = painterResource(id = R.drawable.coffee_cup_bg_ext),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            alignment = Alignment.TopCenter,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    translationY = (-100).dp.toPx()
                    scaleX = 1.10f
                    scaleY = 1.10f
                }
        )

        // Scrim
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(280.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color(0x33000000),
                            Color(0x55000000)
                        )
                    )
                )
        )

        // Sadržaj
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = GataUI.ScreenPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Bottom
        ) {
            when {
                isLoading -> {
                    Text(
                        text = "Tvoja šalica otkriva…",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            color = Color(0xFFFFE9C6),
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp
                        ),
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 18.dp)
                    )
                    
                    CircularProgressIndicator(
                        modifier = Modifier.padding(16.dp),
                        color = Color(0xFFFFE9C6)
                    )
                }
                
                errorMessage != null -> {
                    Text(
                        text = errorMessage ?: "Greška",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            color = Color(0xFFFFE9C6),
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        ),
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 18.dp)
                    )
                    
                    BeanCTA(
                        label = "Pokušaj ponovo",
                        onClick = {
                            scope.launch {
                                isLoading = true
                                errorMessage = null
                                result = null
                                
                                try {
                                    val cleanImageUri = imageUri.split("?")[0]
                                    val uri = Uri.parse(cleanImageUri)
                                    val userInput = preferencesRepo.userInput.first()
                                    
                                    val response = FirebaseFunctionsService.readCup(
                                        imageUri = uri,
                                        context = context,
                                        userInput = userInput
                                    )
                                    
                                    if (!response.isValidCup || response.safetyLevel == "nsfw") {
                                        errorMessage = "Fotografija nije prikladna za čitanje."
                                        isLoading = false
                                        return@launch
                                    }
                                    
                                    val uiModel = GatalinkaReadingUiModel(
                                        mainText = response.mainText,
                                        love = response.love,
                                        work = response.work,
                                        money = response.money,
                                        health = response.health,
                                        symbols = response.symbols,
                                        luckyNumbers = response.luckyNumbers,
                                        luckScore = response.luckScore
                                    )
                                    
                                    result = uiModel
                                    isLoading = false
                                    onViewResult(uiModel)
                                    
                                } catch (e: Exception) {
                                    errorMessage = "Nešto je pošlo po zlu: ${e.message ?: e.javaClass.simpleName}"
                                    isLoading = false
                                }
                            }
                        }
                    )
                    
                    Spacer(Modifier.height(8.dp))
                    
                    BeanCTA(
                        label = "Nazad",
                        onClick = onBack
                    )
                }
                
                result != null -> {
                    // Ovo se ne bi trebalo prikazati jer navigacija treba biti trenutna
                    CircularProgressIndicator(
                        modifier = Modifier.padding(16.dp),
                        color = Color(0xFFFFE9C6)
                    )
                    Text(
                        text = "Čitanje je gotovo!",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            color = Color(0xFFFFE9C6),
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp
                        ),
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 18.dp)
                    )
                }
            }

            Spacer(Modifier.height(40.dp))
        }
    }
}

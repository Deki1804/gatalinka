﻿import * as functions from "firebase-functions";
import * as admin from "firebase-admin";
import { readCup } from "./readCup";

admin.initializeApp();

// Pokušajmo koristiti default region umjesto europe-west1
// Problem: Firebase Functions SDK možda ne prosljeđuje token sa custom regionom
// Rješenje: Koristimo default region (bez .region()) da vidimo da li to rješava problem
export const readCupCallable = functions
  // .region("europe-west1") // TEMPORARNO: Uklonjeno da vidimo da li default region radi
  .runWith({
    timeoutSeconds: 60,
    memory: "1GB",
    minInstances: 0,
    maxInstances: 10
  })
  .https.onCall(async (data, context) => {
    console.log("=== readCupCallable INVOKED ===");
    console.log("context.auth exists:", !!context.auth);
    console.log("context.auth?.uid:", context.auth?.uid);
    console.log("data keys:", Object.keys(data || {}));
    return readCup(data, context);
  });